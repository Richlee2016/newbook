<template>
	<div>
		<v-channel></v-channel>
	</div>
</template>

<script>
import Channel from "./components/Channel";
export default {
  components: {
    "v-channel": Channel
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang='less'>

</style>
