<template>
  <div class="bookIndex">
    <router-view></router-view>
  </div>
</template>

<script>

export default {
  name: 'bookIndex',
}
</script>

<style lang="less">
@import './book.less';
</style>
