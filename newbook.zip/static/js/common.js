//window.onload = function(){
//	pageSize();
//};
////math for page width
//function pageSize()
//{
//	function setRootSize() {
//		var deviceWidth = document.documentElement.clientWidth; 
//		if(deviceWidth>640){deviceWidth = 640;}  
//		document.documentElement.style.fontSize = deviceWidth / 6.4 + 'px';
//	}
//	setRootSize();
//	window.addEventListener('resize', function () {
//	    setRootSize();
//	}, false);
//};
